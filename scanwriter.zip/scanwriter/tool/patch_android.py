#!/usr/bin/env python3
"""پس از `flutter create`، مجوزها و نام برنامه را در پوشه‌ی android تنظیم می‌کند."""
import pathlib
import re

root = pathlib.Path(__file__).resolve().parent.parent
manifest = root / "android/app/src/main/AndroidManifest.xml"
text = manifest.read_text(encoding="utf-8")

# برنامه آفلاین است: مجوز اینترنت عمداً اضافه نمی‌شود.
perms = [
    "android.permission.CAMERA",
]
add = ""
for p in perms:
    if p not in text:
        add += f'    <uses-permission android:name="{p}"/>\n'
if add:
    text = text.replace("<application", add + "    <application", 1)

text = re.sub(r'android:label="[^"]*"', 'android:label="اسکن‌نویس"', text, count=1)
manifest.write_text(text, encoding="utf-8")
print("AndroidManifest.xml patched")

# افزونه‌های قدیمی بدون namespace با AGP 8 ساخته نمی‌شوند؛ namespace از manifest خودشان خوانده می‌شود.
snippet = """// --- patch: namespace برای افزونه‌های قدیمی ---
subprojects {
    afterEvaluate { p ->
        if (p.hasProperty('android') && p.android.hasProperty('namespace') && p.android.namespace == null) {
            def mf = p.android.sourceSets.main.manifest.srcFile
            if (mf.exists()) {
                def pkg = new XmlSlurper().parse(mf).@package.text()
                if (pkg) { p.android.namespace = pkg }
            }
        }
    }
}
// --- end patch ---

"""
for name in ("build.gradle", "build.gradle.kts"):
    f = root / "android" / name
    if f.exists() and name.endswith(".gradle"):
        t = f.read_text(encoding="utf-8")
        if "patch: namespace" not in t:
            f.write_text(snippet + t, encoding="utf-8")
            print(name, "patched")

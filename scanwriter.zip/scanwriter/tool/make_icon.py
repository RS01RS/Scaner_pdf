#!/usr/bin/env python3
"""آیکن برنامه را می‌سازد و در mipmap‌های اندروید می‌نویسد (پس از flutter create اجرا شود).
استفاده: python3 tool/make_icon.py [پوشه‌ی خروجی برای آزمایش]"""
import pathlib
import sys

from PIL import Image, ImageDraw

TEAL = (14, 90, 107, 255)
PAPER = (255, 255, 255, 255)
INK = (14, 90, 107, 255)
GOLD = (242, 209, 75, 255)

S = 1024


def draw():
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, S - 1, S - 1), radius=230, fill=TEAL)
    # برگه با گوشه‌ی تاخورده
    x0, y0, x1, y1, fold = 270, 190, 754, 834, 130
    d.polygon([(x0, y0), (x1 - fold, y0), (x1, y0 + fold), (x1, y1), (x0, y1)], fill=PAPER)
    d.polygon([(x1 - fold, y0), (x1, y0 + fold), (x1 - fold, y0 + fold)], fill=(205, 222, 228, 255))
    # سطرهای متن
    for i, wid in enumerate((330, 330, 330, 220)):
        y = 330 + i * 78
        d.rounded_rectangle((x0 + 62, y, x0 + 62 + wid, y + 26), radius=13, fill=INK)
    # خط اسکن
    d.rounded_rectangle((190, 560, 834, 604), radius=22, fill=GOLD)
    return img


def main():
    img = draw()
    if len(sys.argv) > 1:
        out = pathlib.Path(sys.argv[1])
        out.mkdir(parents=True, exist_ok=True)
        img.resize((192, 192), Image.LANCZOS).save(out / "ic_launcher.png")
        print("آیکن آزمایشی نوشته شد:", out / "ic_launcher.png")
        return
    root = pathlib.Path(__file__).resolve().parent.parent / "android/app/src/main/res"
    for name, size in (("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)):
        d = root / f"mipmap-{name}"
        d.mkdir(parents=True, exist_ok=True)
        img.resize((size, size), Image.LANCZOS).save(d / "ic_launcher.png")
    print("آیکن برنامه ساخته شد.")


if __name__ == "__main__":
    main()

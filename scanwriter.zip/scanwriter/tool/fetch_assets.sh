#!/usr/bin/env bash
# فایل‌های حجیم (داده‌ی OCR فارسی و فونت) را دانلود می‌کند. هنگام ساخت در GitHub Actions خودکار اجرا می‌شود.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p assets/fonts assets/tessdata

dl() { # dl OUT URL [URL...]
  local out="$1"; shift
  if [ -s "$out" ]; then echo "موجود است: $out"; return 0; fi
  for url in "$@"; do
    if curl -fL --retry 3 --retry-delay 2 -o "$out" "$url"; then echo "دانلود شد: $out"; return 0; fi
  done
  echo "دانلود ناموفق: $out" >&2
  exit 1
}

dl assets/tessdata/fas.traineddata \
  https://github.com/tesseract-ocr/tessdata_fast/raw/main/fas.traineddata \
  https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/fas.traineddata
dl assets/tessdata/eng.traineddata \
  https://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata \
  https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/eng.traineddata

for w in Regular Bold; do
  dl "assets/fonts/Vazirmatn-$w.ttf" \
    "https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf/Vazirmatn-$w.ttf" \
    "https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/fonts/ttf/Vazirmatn-$w.ttf"
done

import 'dart:io';
import 'package:flutter/material.dart';
import 'services/storage.dart';

/// اعداد فارسی
String fa(num n) {
  const d = '۰۱۲۳۴۵۶۷۸۹';
  return n.toString().split('').map((c) {
    final i = int.tryParse(c);
    return i == null ? c : d[i];
  }).join();
}

String humanSize(int b) {
  if (b >= 1048576) return '${fa((b / 1048576).toStringAsFixed(1))} مگابایت';
  return '${fa((b / 1024).round())} کیلوبایت';
}

String baseName(String path) => path.split(Platform.pathSeparator).last;

String sanitize(String s) =>
    s.trim().replaceAll(RegExp(r'[\\/:*?"<>|]+'), '-');

void toast(BuildContext c, String m, {SnackBarAction? action}) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), action: action));
}

Future<bool> confirmDialog(BuildContext c, String title, String body,
    {String ok = 'ادامه'}) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لغو')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(ok)),
      ],
    ),
  );
  return r == true;
}

/// پنجره‌ی ذخیره: نام فایل + انتخاب پوشه. فقط مسیر را برمی‌گرداند، نوشتن با فراخواننده است.
Future<File?> chooseSaveTarget(BuildContext context,
    {required String defaultName,
    required String ext,
    String defaultFolder = 'اسناد'}) async {
  final folders = await Store.allFolders();
  final nameC = TextEditingController(text: defaultName);
  Directory sel = folders.firstWhere((d) => Store.rel(d.path) == defaultFolder,
      orElse: () => folders.first);
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, set) => AlertDialog(
        title: const Text('ذخیره در پوشه'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameC,
              decoration: const InputDecoration(labelText: 'نام فایل'),
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<Directory>(
              value: sel,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'پوشه'),
              items: [
                for (final d in folders)
                  DropdownMenuItem(value: d, child: Text(Store.rel(d.path)))
              ],
              onChanged: (v) {
                if (v != null) set(() => sel = v);
              },
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('ذخیره')),
        ],
      ),
    ),
  );
  if (ok != true) return null;
  final base = sanitize(nameC.text);
  final path = await Store.uniquePath(sel.path, base.isEmpty ? 'scan' : base, ext);
  return File(path);
}

/// انتخاب یک پوشه (برای انتقال فایل)
Future<Directory?> pickFolder(BuildContext context, {String title = 'انتقال به پوشه'}) async {
  final folders = [Store.root, ...await Store.allFolders()];
  return showDialog<Directory>(
    context: context,
    builder: (c) => SimpleDialog(
      title: Text(title),
      children: [
        for (final d in folders)
          SimpleDialogOption(
            onPressed: () => Navigator.pop(c, d),
            child: Text(d.path == Store.root.path ? 'پوشه‌ی اصلی' : Store.rel(d.path)),
          ),
      ],
    ),
  );
}

/// پنجره‌ی پیشرفت با مقدار بین ۰ و ۱
class ProgressDialog {
  final ValueNotifier<double> value = ValueNotifier(0);
  final ValueNotifier<String> label;
  final BuildContext context;
  ProgressDialog(this.context, String initial) : label = ValueNotifier(initial);

  void show() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => PopScope(
        canPop: false,
        child: AlertDialog(
          content: ValueListenableBuilder<String>(
            valueListenable: label,
            builder: (_, l, __) => ValueListenableBuilder<double>(
              valueListenable: value,
              builder: (_, v, __) => Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(l),
                  const SizedBox(height: 14),
                  LinearProgressIndicator(value: v <= 0 ? null : v),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void close() {
    if (Navigator.of(context, rootNavigator: true).canPop()) {
      Navigator.of(context, rootNavigator: true).pop();
    }
  }
}

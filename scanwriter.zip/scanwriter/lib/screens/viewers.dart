import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../services/storage.dart';
import '../util.dart';

/// باز کردن فایل ذخیره‌شده بر اساس نوع آن
Future<void> openStoredFile(BuildContext context, File f) async {
  final kind = Store.kindOf(f.path);
  Widget? page;
  if (kind == 'pdf') page = PdfViewScreen(file: f);
  if (kind == 'image') page = ImageViewScreen(file: f);
  if (kind == 'text') page = TextViewScreen(file: f);
  if (page == null) {
    await Share.shareXFiles([XFile(f.path)]);
    return;
  }
  await Navigator.of(context).push(MaterialPageRoute(builder: (_) => page!));
}

class PdfViewScreen extends StatelessWidget {
  final File file;
  const PdfViewScreen({super.key, required this.file});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(baseName(file.path), overflow: TextOverflow.ellipsis)),
      body: PdfPreview(
        build: (format) => file.readAsBytes(),
        canChangeOrientation: false,
        canChangePageFormat: false,
        canDebug: false,
        pdfFileName: baseName(file.path),
      ),
    );
  }
}

class ImageViewScreen extends StatelessWidget {
  final File file;
  const ImageViewScreen({super.key, required this.file});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(baseName(file.path), overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () => Share.shareXFiles([XFile(file.path)]),
          ),
        ],
      ),
      body: InteractiveViewer(maxScale: 6, child: Center(child: Image.file(file))),
    );
  }
}

class TextViewScreen extends StatefulWidget {
  final File file;
  const TextViewScreen({super.key, required this.file});

  @override
  State<TextViewScreen> createState() => _TextViewScreenState();
}

class _TextViewScreenState extends State<TextViewScreen> {
  final c = TextEditingController();

  @override
  void initState() {
    super.initState();
    widget.file.readAsString().then((t) => setState(() => c.text = t));
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(baseName(widget.file.path), overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: const Icon(Icons.copy),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: c.text));
              if (mounted) toast(context, 'کپی شد.');
            },
          ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: () async {
              await widget.file.writeAsString(c.text);
              if (mounted) toast(context, 'تغییرات ذخیره شد.');
            },
          ),
          IconButton(icon: const Icon(Icons.share), onPressed: () => Share.share(c.text)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: TextField(
          controller: c,
          maxLines: null,
          expands: true,
          textAlignVertical: TextAlignVertical.top,
          style: const TextStyle(height: 1.9),
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
      ),
    );
  }
}

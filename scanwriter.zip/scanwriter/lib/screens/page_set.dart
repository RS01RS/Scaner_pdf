import 'dart:convert';
import 'dart:io';
import 'package:cunning_document_scanner/cunning_document_scanner.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/imaging.dart';
import '../services/pdf_writer.dart';
import '../services/storage.dart';
import '../util.dart';
import 'summary_screen.dart';

enum SetMode { book, scanner, pdfEditor, summary }

/// صفحه‌ی مشترک برای: کتاب به PDF، اسکنر مدارک، ویرایشگر PDF و ورودی خلاصه‌سازی.
/// صفحه‌ها (تا ۳۰۰) به‌صورت فایل نگه داشته می‌شوند و با بستن برنامه از بین نمی‌روند.
class PageSetScreen extends StatefulWidget {
  final SetMode mode;
  const PageSetScreen({super.key, required this.mode});

  @override
  State<PageSetScreen> createState() => _PageSetScreenState();
}

class _PageSetScreenState extends State<PageSetScreen> {
  static const int maxPages = 300;
  static const int bookMin = 20;

  final List<PageItem> pages = [];
  final Set<int> sel = {};
  late Directory dir;
  bool loading = true;
  bool busy = false;
  String busyMsg = '';
  final picker = ImagePicker();
  final titleC = TextEditingController();
  String defFilter = 'none';

  String get key => 'session_${widget.mode.name}';

  @override
  void initState() {
    super.initState();
    dir = Store.sessionDir(widget.mode.name);
    defFilter = widget.mode == SetMode.scanner ? 'document' : 'none';
    _restore();
  }

  @override
  void dispose() {
    titleC.dispose();
    super.dispose();
  }

  Future<void> _restore() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(key);
    if (raw != null) {
      try {
        for (final m in jsonDecode(raw) as List) {
          final it = PageItem.fromJson(m);
          if (await File(it.path).exists()) pages.add(it);
        }
      } catch (_) {}
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _persist() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(key, jsonEncode(pages.map((e) => e.toJson()).toList()));
  }

  void _changed() {
    sel.removeWhere((i) => i >= pages.length);
    _persist();
    if (mounted) setState(() {});
  }

  // ---------------- افزودن صفحه ----------------
  Future<void> _addPaths(List<String> paths) async {
    setState(() {
      busy = true;
      busyMsg = '';
    });
    var n = 0;
    for (final p in paths) {
      if (pages.length >= maxPages) {
        if (mounted) toast(context, 'حداکثر ${fa(maxPages)} صفحه پشتیبانی می‌شود.');
        break;
      }
      n++;
      if (mounted) setState(() => busyMsg = 'در حال آماده‌سازی ${fa(n)} از ${fa(paths.length)}…');
      try {
        // برای خلاصه‌سازی (که متن را می‌خواند) رزولوشن بالاتر لازم است
        final it = await Imaging.importImage(p, dir, minSize: widget.mode == SetMode.summary ? 2000 : 1300);
        if (it != null) {
          if (defFilter != 'none') {
            if (mounted) setState(() => busyMsg = 'در حال اعمال فیلتر ${fa(n)} از ${fa(paths.length)}…');
            try {
              pages.add(await Imaging.applyFilter(it, defFilter, dir));
            } catch (_) {
              pages.add(it);
            }
          } else {
            pages.add(it);
          }
        }
      } catch (_) {}
    }
    busy = false;
    _changed();
  }

  Future<void> _scanner() async {
    try {
      final list = await CunningDocumentScanner.getPictures();
      if (list != null && list.isNotEmpty) await _addPaths(list);
    } catch (e) {
      if (mounted) toast(context, 'اسکنر باز نشد. از «دوربین» یا «گالری» استفاده کنید.');
    }
  }

  Future<void> _cameraLoop() async {
    while (pages.length < maxPages) {
      final x = await picker.pickImage(source: ImageSource.camera);
      if (x == null) break;
      await _addPaths([x.path]);
      if (!mounted) return;
    }
  }

  Future<void> _gallery() async {
    final xs = await picker.pickMultiImage();
    if (xs.isEmpty) return;
    await _addPaths(xs.map((e) => e.path).toList());
  }

  Future<void> _importPdfs() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      allowMultiple: true,
    );
    if (r == null) return;
    setState(() {
      busy = true;
      busyMsg = 'در حال باز کردن PDF…';
    });
    try {
      for (final f in r.files) {
        if (f.path == null) continue;
        final bytes = await File(f.path!).readAsBytes();
        await for (final pr in Printing.raster(bytes, dpi: widget.mode == SetMode.summary ? 200 : 130)) {
          if (pages.length >= maxPages) {
            if (mounted) toast(context, 'حداکثر ${fa(maxPages)} صفحه پشتیبانی می‌شود.');
            break;
          }
          final png = await pr.toPng();
          pages.add(await Imaging.fromPng(png, dir));
          if (mounted) setState(() => busyMsg = '${fa(pages.length)} صفحه آماده شد…');
        }
      }
    } catch (e) {
      if (mounted) toast(context, 'این PDF باز نشد.');
    }
    busy = false;
    _changed();
  }

  // ---------------- ویرایش ----------------
  Future<void> _rotate() async {
    if (sel.isEmpty) return;
    setState(() {
      busy = true;
      busyMsg = 'در حال چرخاندن…';
    });
    for (final i in sel.toList()) {
      pages[i] = await Imaging.rotate90(pages[i], dir);
    }
    busy = false;
    _changed();
  }

  Future<void> _delete() async {
    if (sel.isEmpty) return;
    final ok = await confirmDialog(context, 'حذف صفحه', '${fa(sel.length)} صفحه حذف شود؟', ok: 'حذف');
    if (!ok) return;
    final idx = sel.toList()..sort((a, b) => b.compareTo(a));
    for (final i in idx) {
      try {
        await File(pages[i].path).delete();
        if (pages[i].orig != null) await File(pages[i].orig!).delete();
      } catch (_) {}
      pages.removeAt(i);
    }
    sel.clear();
    _changed();
  }

  void _move(int d) {
    if (sel.length != 1) return;
    final i = sel.first;
    final j = i + d;
    if (j < 0 || j >= pages.length) return;
    final t = pages[i];
    pages[i] = pages[j];
    pages[j] = t;
    sel
      ..clear()
      ..add(j);
    _changed();
  }

  Future<void> _stamp() async {
    if (sel.length != 1) {
      toast(context, 'برای نوشتن متن یک صفحه را انتخاب کنید.');
      return;
    }
    final c = TextEditingController();
    var pos = 0.5;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('نوشتن متن روی صفحه'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: c, decoration: const InputDecoration(labelText: 'متن')),
              const SizedBox(height: 12),
              SegmentedButton<double>(
                segments: const [
                  ButtonSegment(value: 0.02, label: Text('بالا')),
                  ButtonSegment(value: 0.5, label: Text('وسط')),
                  ButtonSegment(value: 0.98, label: Text('پایین')),
                ],
                selected: {pos},
                onSelectionChanged: (s) => set(() => pos = s.first),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لغو')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('درج')),
          ],
        ),
      ),
    );
    if (ok != true || c.text.trim().isEmpty) return;
    setState(() {
      busy = true;
      busyMsg = 'در حال درج متن…';
    });
    final i = sel.first;
    final old = pages[i];
    pages[i] = await Imaging.stampText(old, c.text.trim(), pos, dir);
    if (old.orig != null) {
      try {
        await File(old.orig!).delete();
      } catch (_) {}
    }
    busy = false;
    _changed();
  }

  Future<void> _filterSheet() async {
    final f = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                sel.isEmpty ? 'فیلتر برای همه‌ی صفحه‌ها' : 'فیلتر برای ${fa(sel.length)} صفحه‌ی انتخاب‌شده',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.image_outlined),
              title: const Text('اصلی'),
              subtitle: const Text('برگرداندن عکس اولیه'),
              onTap: () => Navigator.pop(ctx, 'none'),
            ),
            ListTile(
              leading: const Icon(Icons.description_outlined),
              title: const Text('سند'),
              subtitle: const Text('زمینه‌ی سفید و متن خوانا، رنگ‌ها حفظ می‌شود'),
              onTap: () => Navigator.pop(ctx, 'document'),
            ),
            ListTile(
              leading: const Icon(Icons.contrast),
              title: const Text('سیاه‌وسفید'),
              subtitle: const Text('مناسب نسخه‌برداری و چاپ'),
              onTap: () => Navigator.pop(ctx, 'bw'),
            ),
          ],
        ),
      ),
    );
    if (f == null) return;
    final targets = sel.isEmpty ? List.generate(pages.length, (i) => i) : (sel.toList()..sort());
    setState(() => busy = true);
    for (var k = 0; k < targets.length; k++) {
      if (mounted) setState(() => busyMsg = 'در حال اعمال فیلتر ${fa(k + 1)} از ${fa(targets.length)}…');
      try {
        pages[targets[k]] = await Imaging.applyFilter(pages[targets[k]], f, dir);
      } catch (_) {}
    }
    busy = false;
    _changed();
  }

  void _preview(int i) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: Stack(
          children: [
            InteractiveViewer(child: Image.file(File(pages[i].path))),
            Positioned(
              top: 4,
              left: 4,
              child: IconButton.filledTonal(
                  onPressed: () => Navigator.pop(ctx), icon: const Icon(Icons.close)),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _clearAll() async {
    final ok = await confirmDialog(context, 'پاک کردن همه', 'همه‌ی صفحه‌های این بخش پاک شود؟', ok: 'پاک کن');
    if (!ok) return;
    for (final p in pages) {
      try {
        await File(p.path).delete();
        if (p.orig != null) await File(p.orig!).delete();
      } catch (_) {}
    }
    pages.clear();
    sel.clear();
    _changed();
  }

  // ---------------- خروجی ----------------
  Future<void> _exportPdf() async {
    if (pages.isEmpty) return;
    if (widget.mode == SetMode.book && pages.length < bookMin) {
      final ok = await confirmDialog(
        context,
        'تعداد صفحه کم است',
        'این بخش برای کتاب ${fa(bookMin)} تا ${fa(maxPages)} صفحه‌ای است و شما ${fa(pages.length)} صفحه دارید. '
            'برای مدارک کوتاه «اسکنر مدارک» مناسب‌تر است. با همین تعداد PDF ساخته شود؟',
      );
      if (!ok) return;
    }
    final def = titleC.text.trim().isEmpty ? _defaultName() : titleC.text.trim();
    final target = await chooseSaveTarget(context, defaultName: def, ext: 'pdf', defaultFolder: 'PDF');
    if (target == null) return;
    final pd = ProgressDialog(context, 'در حال ساخت PDF…')..show();
    try {
      await PdfWriter.write(pages, target.path, onProgress: (d, t) {
        pd.value.value = d / t;
        pd.label.value = 'صفحه ${fa(d)} از ${fa(t)}';
      });
      pd.close();
      if (!mounted) return;
      final size = await target.length();
      toast(
        context,
        'PDF ذخیره شد (${humanSize(size)}) در ${Store.rel(target.parent.path)}',
        action: SnackBarAction(
          label: 'اشتراک‌گذاری',
          onPressed: () => Share.shareXFiles([XFile(target.path)]),
        ),
      );
    } catch (e) {
      pd.close();
      if (mounted) toast(context, 'ساخت PDF انجام نشد.');
    }
  }

  String _defaultName() {
    switch (widget.mode) {
      case SetMode.book:
        return 'کتاب';
      case SetMode.scanner:
        return 'مدرک';
      case SetMode.pdfEditor:
        return 'ویرایش‌شده';
      case SetMode.summary:
        return 'جزوه';
    }
  }

  Future<void> _saveImages() async {
    if (pages.isEmpty) return;
    final def = titleC.text.trim().isEmpty ? _defaultName() : titleC.text.trim();
    final target = await chooseSaveTarget(context, defaultName: def, ext: 'jpg', defaultFolder: 'تصاویر');
    if (target == null) return;
    final base = target.path.substring(0, target.path.length - 4);
    for (var i = 0; i < pages.length; i++) {
      await File(pages[i].path).copy('$base-${(i + 1).toString().padLeft(3, '0')}.jpg');
    }
    if (mounted) toast(context, '${fa(pages.length)} تصویر ذخیره شد.');
  }

  void _summarize() {
    if (pages.isEmpty) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => SummaryScreen(pages: List.of(pages), title: titleC.text.trim()),
    ));
  }

  // ---------------- ظاهر ----------------
  String get hint {
    switch (widget.mode) {
      case SetMode.book:
        return 'کتاب ${fa(bookMin)} تا ${fa(maxPages)} صفحه‌ای را صفحه‌به‌صفحه عکس بگیرید یا از گالری بیاورید؛ همه در یک PDF می‌روند.';
      case SetMode.scanner:
        return 'اسکنر لبه‌های برگه را پیدا می‌کند و صاف می‌کند. فیلتر «سند» زمینه را سفید و متن را خوانا می‌کند. برای شناسنامه، کارت ملی و قبض مناسب است.';
      case SetMode.pdfEditor:
        return 'PDF بیاورید، صفحه‌ها را حذف، جابه‌جا، بچرخانید، متن روی آن‌ها بنویسید و چند PDF را یکی کنید.';
      case SetMode.summary:
        return 'صفحه‌های جزوه یا کتاب را اضافه کنید (تا ${fa(maxPages)} صفحه)، بعد «خلاصه‌سازی» را بزنید.';
    }
  }

  List<Widget> _addButtons() {
    Widget b(String t, IconData i, VoidCallback f, {bool primary = false}) {
      final child = Row(mainAxisSize: MainAxisSize.min, children: [Icon(i, size: 20), const SizedBox(width: 6), Text(t)]);
      return primary
          ? FilledButton(onPressed: busy ? null : f, child: child)
          : OutlinedButton(onPressed: busy ? null : f, child: child);
    }

    switch (widget.mode) {
      case SetMode.book:
        return [
          b('دوربین پشت‌سرهم', Icons.photo_camera, _cameraLoop, primary: true),
          b('اسکنر لبه‌یاب', Icons.document_scanner, _scanner),
          b('گالری', Icons.photo_library, _gallery),
        ];
      case SetMode.scanner:
        return [
          b('اسکن مدرک', Icons.document_scanner, _scanner, primary: true),
          b('دوربین ساده', Icons.photo_camera, _cameraLoop),
          b('گالری', Icons.photo_library, _gallery),
        ];
      case SetMode.pdfEditor:
        return [
          b('افزودن PDF', Icons.picture_as_pdf, _importPdfs, primary: true),
          b('گالری', Icons.photo_library, _gallery),
          b('دوربین', Icons.photo_camera, _cameraLoop),
        ];
      case SetMode.summary:
        return [
          b('اسکنر لبه‌یاب', Icons.document_scanner, _scanner, primary: true),
          b('دوربین پشت‌سرهم', Icons.photo_camera, _cameraLoop),
          b('گالری', Icons.photo_library, _gallery),
          b('از PDF', Icons.picture_as_pdf, _importPdfs),
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    final cs = Theme.of(context).colorScheme;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(hint, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13.5)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: _addButtons()),
              if (widget.mode == SetMode.scanner || widget.mode == SetMode.book) ...[
                const SizedBox(height: 10),
                Row(children: [
                  Text('فیلتر صفحه‌های جدید:', style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant)),
                  const SizedBox(width: 8),
                  for (final e in const {'none': 'اصلی', 'document': 'سند', 'bw': 'سیاه‌وسفید'}.entries)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 6),
                      child: ChoiceChip(
                        label: Text(e.value),
                        selected: defFilter == e.key,
                        visualDensity: VisualDensity.compact,
                        onSelected: busy ? null : (_) => setState(() => defFilter = e.key),
                      ),
                    ),
                ]),
              ],
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: titleC,
                      decoration: const InputDecoration(
                        isDense: true,
                        labelText: 'نام کتاب یا سند (اختیاری)',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text('${fa(pages.length)} / ${fa(maxPages)}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ],
          ),
        ),
        if (busy)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(children: [
              const LinearProgressIndicator(),
              const SizedBox(height: 4),
              Text(busyMsg, style: const TextStyle(fontSize: 13)),
            ]),
          ),
        Expanded(
          child: pages.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Text('هنوز صفحه‌ای اضافه نشده.',
                        style: TextStyle(color: cs.onSurfaceVariant)),
                  ),
                )
              : GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                    childAspectRatio: 0.72,
                  ),
                  itemCount: pages.length,
                  itemBuilder: (_, i) {
                    final on = sel.contains(i);
                    return GestureDetector(
                      onTap: () => setState(() => on ? sel.remove(i) : sel.add(i)),
                      onLongPress: () => _preview(i),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: on ? cs.primary : Colors.transparent, width: 3),
                        ),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(5),
                              child: Image.file(File(pages[i].path), fit: BoxFit.cover, cacheWidth: 300),
                            ),
                            Positioned(
                              top: 4,
                              right: 4,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF2D14B),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(fa(i + 1),
                                    style: const TextStyle(
                                        color: Color(0xFF2A2300), fontSize: 12, fontWeight: FontWeight.w700)),
                              ),
                            ),
                            if (on)
                              Positioned(
                                bottom: 4,
                                left: 4,
                                child: Icon(Icons.check_circle, color: cs.primary),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
        if (pages.isNotEmpty) _selectionBar(cs),
        _actionBar(),
      ],
    );
  }

  Widget _selectionBar(ColorScheme cs) {
    final one = sel.length == 1;
    Widget ib(IconData i, String tip, VoidCallback? f) =>
        IconButton(tooltip: tip, onPressed: busy ? null : f, icon: Icon(i));
    return Container(
      color: cs.surfaceContainerHighest,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
        children: [
          Text(sel.isEmpty ? 'صفحه را لمس کنید' : '${fa(sel.length)} انتخاب',
              style: const TextStyle(fontSize: 13)),
          const SizedBox(width: 16),
          ib(Icons.select_all, 'انتخاب همه', () => setState(() {
                if (sel.length == pages.length) {
                  sel.clear();
                } else {
                  sel
                    ..clear()
                    ..addAll(List.generate(pages.length, (i) => i));
                }
              })),
          ib(Icons.arrow_forward, 'جلوتر', one ? () => _move(-1) : null),
          ib(Icons.arrow_back, 'عقب‌تر', one ? () => _move(1) : null),
          ib(Icons.rotate_right, 'چرخاندن', sel.isEmpty ? null : _rotate),
          ib(Icons.auto_fix_high, 'فیلتر سند', _filterSheet),
          if (widget.mode == SetMode.pdfEditor) ib(Icons.text_fields, 'نوشتن متن', one ? _stamp : null),
          ib(Icons.delete_outline, 'حذف', sel.isEmpty ? null : _delete),
        ],
      ),
      ),
    );
  }

  Widget _actionBar() {
    final has = pages.isNotEmpty && !busy;
    final buttons = <Widget>[];
    if (widget.mode == SetMode.summary) {
      buttons.add(Expanded(
        child: FilledButton.icon(
          onPressed: has ? _summarize : null,
          icon: const Icon(Icons.auto_awesome),
          label: const Text('خلاصه‌سازی'),
        ),
      ));
    } else {
      buttons.add(Expanded(
        child: FilledButton.icon(
          onPressed: has ? _exportPdf : null,
          icon: const Icon(Icons.picture_as_pdf),
          label: const Text('ساخت PDF'),
        ),
      ));
      if (widget.mode == SetMode.scanner) {
        buttons.add(const SizedBox(width: 8));
        buttons.add(OutlinedButton(onPressed: has ? _saveImages : null, child: const Text('ذخیره تصویر')));
      }
    }
    buttons.add(const SizedBox(width: 8));
    buttons.add(IconButton.outlined(
      tooltip: 'پاک کردن همه',
      onPressed: pages.isEmpty || busy ? null : _clearAll,
      icon: const Icon(Icons.delete_sweep_outlined),
    ));
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        child: Row(children: buttons),
      ),
    );
  }
}

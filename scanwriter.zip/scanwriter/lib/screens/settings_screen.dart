import 'package:flutter/material.dart';
import '../services/settings.dart';
import '../util.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String lang = AppSettings.ocrLang;

  Future<void> _save() async {
    AppSettings.ocrLang = lang;
    await AppSettings.save();
    if (mounted) toast(context, 'تنظیمات ذخیره شد.');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('زبان تشخیص متن', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        const SizedBox(height: 6),
        Text(
          'اگر متن فقط فارسی یا فقط انگلیسی است، همان را انتخاب کنید تا دقت و سرعت بیشتر شود.',
          style: TextStyle(color: cs.onSurfaceVariant, height: 1.7),
        ),
        const SizedBox(height: 12),
        for (final e in AppSettings.langs.entries)
          RadioListTile<String>(
            value: e.key,
            groupValue: lang,
            title: Text(e.value),
            onChanged: (v) => setState(() => lang = v ?? lang),
          ),
        const SizedBox(height: 12),
        FilledButton(onPressed: _save, child: const Text('ذخیره')),
        const SizedBox(height: 26),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: cs.surfaceContainerHigh, borderRadius: BorderRadius.circular(12)),
          child: Text(
            'این برنامه کاملاً رایگان است و به اینترنت، حساب کاربری یا کلید API نیاز ندارد. '
            'داده‌ی تشخیص متن، فونت و خلاصه‌ساز داخل خود برنامه هستند و هیچ فایلی از گوشی شما خارج نمی‌شود، '
            'مگر وقتی خودتان «ارسال» را بزنید.',
            style: TextStyle(height: 1.8, color: cs.onSurface),
          ),
        ),
        const SizedBox(height: 16),
        Text('اسکن‌نویس نسخه‌ی ۱٫۰', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12.5)),
      ],
    );
  }
}

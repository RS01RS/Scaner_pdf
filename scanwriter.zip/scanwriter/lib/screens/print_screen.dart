import 'dart:io';
import 'dart:typed_data';
import 'package:android_intent_plus/android_intent.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import '../services/imaging.dart';
import '../services/pdf_writer.dart';
import '../services/storage.dart';
import '../util.dart';

/// فایل را (PDF، تصویر یا متن) به سیستم چاپ اندروید می‌دهد.
Future<void> printStoredFile(BuildContext context, File f) async {
  try {
    final kind = Store.kindOf(f.path);
    late final List<int> bytes;
    if (kind == 'pdf') {
      bytes = await f.readAsBytes();
    } else {
      final tmp = Store.tempDir('print_tmp');
      if (await tmp.exists()) await tmp.delete(recursive: true);
      await tmp.create(recursive: true);
      List<PageItem> pages;
      if (kind == 'image') {
        final it = await Imaging.importImage(f.path, tmp, minSize: 2000, quality: 90);
        if (it == null) throw Exception('img');
        pages = [it];
      } else if (kind == 'text') {
        pages = await Imaging.renderTextPages('', '', Imaging.parseBlocks(await f.readAsString()), tmp);
      } else {
        toast(context, 'این نوع فایل قابل چاپ نیست.');
        return;
      }
      final out = '${tmp.path}/print.pdf';
      await PdfWriter.write(pages, out);
      bytes = await File(out).readAsBytes();
    }
    await Printing.layoutPdf(
      name: baseName(f.path),
      onLayout: (format) async => Uint8List.fromList(bytes),
    );
  } catch (e) {
    if (context.mounted) toast(context, 'چاپ شروع نشد.');
  }
}

class PrintScreen extends StatelessWidget {
  const PrintScreen({super.key});

  Future<void> _pickStored(BuildContext context) async {
    final files = (await Store.allFiles()).where((f) => Store.kindOf(f.path) != 'other').toList();
    if (!context.mounted) return;
    if (files.isEmpty) {
      toast(context, 'هنوز فایلی ذخیره نشده است.');
      return;
    }
    final f = await showModalBottomSheet<File>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .7,
        builder: (_, sc) => ListView.builder(
          controller: sc,
          itemCount: files.length,
          itemBuilder: (_, i) => ListTile(
            leading: Icon(Store.kindOf(files[i].path) == 'pdf' ? Icons.picture_as_pdf : Icons.insert_drive_file),
            title: Text(baseName(files[i].path), overflow: TextOverflow.ellipsis),
            subtitle: Text(Store.rel(files[i].parent.path)),
            onTap: () => Navigator.pop(ctx, files[i]),
          ),
        ),
      ),
    );
    if (f != null && context.mounted) await printStoredFile(context, f);
  }

  Future<void> _pickDevice(BuildContext context) async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'txt'],
    );
    if (r == null || r.files.single.path == null) return;
    if (context.mounted) await printStoredFile(context, File(r.files.single.path!));
  }

  Future<void> _settings(BuildContext context) async {
    try {
      await const AndroidIntent(action: 'android.settings.ACTION_PRINT_SETTINGS').launch();
    } catch (_) {
      if (context.mounted) toast(context, 'تنظیمات چاپ باز نشد. از تنظیمات گوشی > چاپ بروید.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget step(String n, String t) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 12, backgroundColor: const Color(0xFFF2D14B),
                child: Text(n, style: const TextStyle(color: Color(0xFF2A2300), fontSize: 12, fontWeight: FontWeight.w700))),
            const SizedBox(width: 10),
            Expanded(child: Text(t, style: const TextStyle(height: 1.7))),
          ]),
        );
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('اتصال به چاپگر و چاپ مدارک و PDF', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Text('چاپ از سیستم چاپ خود اندروید انجام می‌شود، پس هر چاپگری که گوشی ببیند (وای‌فای، شبکه‌ی خانگی، وای‌فای دایرکت) کار می‌کند.',
            style: TextStyle(color: cs.onSurfaceVariant, height: 1.7)),
        const SizedBox(height: 16),
        FilledButton.icon(
            onPressed: () => _pickStored(context), icon: const Icon(Icons.folder_open), label: const Text('چاپ از فایل‌های ذخیره‌شده')),
        const SizedBox(height: 8),
        OutlinedButton.icon(
            onPressed: () => _pickDevice(context), icon: const Icon(Icons.upload_file), label: const Text('چاپ فایل از حافظه‌ی گوشی')),
        const SizedBox(height: 8),
        OutlinedButton.icon(
            onPressed: () => _settings(context), icon: const Icon(Icons.print), label: const Text('اتصال و تنظیم چاپگر (تنظیمات سیستم)')),
        const SizedBox(height: 22),
        const Text('راهنمای اتصال', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        step('۱', 'گوشی و چاپگر را به یک وای‌فای وصل کنید (یا وای‌فای دایرکت چاپگر را روشن کنید).'),
        step('۲', '«اتصال و تنظیم چاپگر» را بزنید و «Default Print Service» را روشن کنید. چاپگر خودش پیدا می‌شود.'),
        step('۳', 'اگر چاپگر پیدا نشد، افزونه‌ی چاپ برند خود (HP، Canon، Epson، Brother، Samsung) را از فروشگاه نصب کنید.'),
        step('۴', 'فایل را انتخاب کنید و در پنجره‌ی چاپ، چاپگر، تعداد و اندازه‌ی کاغذ را تعیین کنید.'),
        const SizedBox(height: 8),
        Text('همین پنجره‌ی چاپ گزینه‌ی «ذخیره به‌صورت PDF» هم دارد.',
            style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
      ],
    );
  }
}

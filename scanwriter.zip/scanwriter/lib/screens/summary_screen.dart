import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../services/imaging.dart';
import '../services/ocr.dart';
import '../services/pdf_writer.dart';
import '../services/storage.dart';
import '../services/summarizer.dart';
import '../util.dart';

/// خلاصه‌سازی آفلاین: از صفحه‌های عکس‌شده (pages) یا از یک متن (text).
/// مرحله‌ی ۱: خواندن متن هر صفحه (Tesseract). مرحله‌ی ۲: انتخاب مهم‌ترین جمله‌ها.
class SummaryScreen extends StatefulWidget {
  final List<PageItem>? pages;
  final String? text;
  final String title;
  const SummaryScreen({super.key, this.pages, this.text, this.title = ''});

  @override
  State<SummaryScreen> createState() => _SummaryScreenState();
}

class _SummaryScreenState extends State<SummaryScreen> {
  String length = 'mid';
  bool running = false;
  bool stop = false;
  String msg = '';
  double prog = 0;
  String result = '';
  String fullText = '';

  int get count => widget.pages?.length ?? 0;

  /// متن بلند را به تکه‌های حدود ۳۰۰۰ نویسه‌ای (در مرز پاراگراف) می‌شکند
  List<String> _chunk(String t) {
    final out = <String>[];
    var cur = StringBuffer();
    for (final p in t.split(RegExp(r'\n\s*\n'))) {
      if (cur.length + p.length > 3000 && cur.isNotEmpty) {
        out.add(cur.toString());
        cur = StringBuffer();
      }
      cur.write('$p\n\n');
    }
    if (cur.isNotEmpty) out.add(cur.toString());
    return out;
  }

  Future<void> _run() async {
    setState(() {
      running = true;
      stop = false;
      result = '';
      fullText = '';
      msg = 'شروع…';
      prog = 0;
    });
    try {
      List<String> texts;
      if (widget.pages != null) {
        texts = [];
        final pages = widget.pages!;
        for (var i = 0; i < pages.length; i++) {
          if (stop) break;
          setState(() {
            msg = 'در حال خواندن صفحه‌ی ${fa(i + 1)} از ${fa(pages.length)}…';
            prog = i / pages.length * 0.95;
          });
          texts.add(await Ocr.read(pages[i]));
        }
        if (stop) {
          if (mounted) setState(() => running = false);
          if (mounted) toast(context, 'متوقف شد.');
          return;
        }
        fullText = [
          for (var i = 0; i < texts.length; i++) '— صفحه‌ی ${fa(i + 1)} —\n${texts[i]}',
        ].join('\n\n');
      } else {
        texts = _chunk(widget.text!);
        fullText = widget.text!;
      }
      setState(() {
        msg = 'در حال انتخاب نکته‌های مهم…';
        prog = 0.97;
      });
      final s = await summarizeOffline(texts, length, pagesMode: widget.pages != null);
      if (!mounted) return;
      if (s.isEmpty) {
        toast(context, 'متن کافی برای خلاصه‌کردن خوانده نشد. عکس‌های واضح‌تر و صاف‌تر بگیرید.');
      }
      setState(() => result = s);
    } catch (e) {
      if (mounted) toast(context, 'خلاصه‌سازی انجام نشد. دوباره امتحان کنید.');
    }
    if (mounted) setState(() => running = false);
  }

  Future<void> _savePdf() async {
    final blocks = Imaging.parseBlocks(result);
    final target = await chooseSaveTarget(context,
        defaultName: widget.title.isEmpty ? 'خلاصه' : 'خلاصه‌ی ${widget.title}', ext: 'pdf', defaultFolder: 'خلاصه‌ها');
    if (target == null) return;
    final pd = ProgressDialog(context, 'در حال ساخت PDF خلاصه…')..show();
    try {
      final tmp = Store.tempDir('summary_pdf');
      if (await tmp.exists()) await tmp.delete(recursive: true);
      final pages = await Imaging.renderTextPages(
        widget.title,
        widget.pages != null ? 'خلاصه‌ی ${fa(count)} صفحه' : 'خلاصه‌ی متن',
        blocks,
        tmp,
      );
      await PdfWriter.write(pages, target.path);
      await tmp.delete(recursive: true);
      pd.close();
      if (!mounted) return;
      toast(context, 'PDF خلاصه ذخیره شد.',
          action: SnackBarAction(
            label: 'اشتراک‌گذاری',
            onPressed: () => Share.shareXFiles([XFile(target.path)]),
          ));
    } catch (e) {
      pd.close();
      if (mounted) toast(context, 'ساخت PDF انجام نشد.');
    }
  }

  Future<void> _saveTxt(String content, String name) async {
    final target = await chooseSaveTarget(context, defaultName: name, ext: 'txt', defaultFolder: 'خلاصه‌ها');
    if (target == null) return;
    await target.writeAsString(content);
    if (mounted) toast(context, 'ذخیره شد.');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final blocks = Imaging.parseBlocks(result);
    return Scaffold(
      appBar: AppBar(title: const Text('خلاصه‌سازی')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (widget.pages != null)
            Text('تعداد صفحه: ${fa(count)}', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          const SizedBox(height: 8),
          Text(
            'متن هر صفحه روی گوشی خوانده می‌شود (چند ثانیه برای هر صفحه) و مهم‌ترین جمله‌های خود متن انتخاب می‌شوند؛ بازنویسی نمی‌شوند. اینترنت و حساب لازم نیست. کیفیت به وضوح عکس‌ها بستگی دارد.',
            style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13, height: 1.7),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: length,
            decoration: const InputDecoration(labelText: 'اندازه‌ی خلاصه', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'short', child: Text('کوتاه (حدود ۱۲ جمله)')),
              DropdownMenuItem(value: 'mid', child: Text('متوسط (حدود ۳۰ جمله)')),
              DropdownMenuItem(value: 'long', child: Text('مفصل (حدود ۶۰ جمله)')),
            ],
            onChanged: running ? null : (v) => setState(() => length = v ?? 'mid'),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: running ? null : _run,
                icon: const Icon(Icons.auto_awesome),
                label: const Text('خلاصه کن'),
              ),
            ),
            if (running) ...[
              const SizedBox(width: 8),
              OutlinedButton(onPressed: () => setState(() => stop = true), child: const Text('توقف')),
            ],
          ]),
          if (running) ...[
            const SizedBox(height: 14),
            LinearProgressIndicator(value: prog <= 0 ? null : prog),
            const SizedBox(height: 6),
            Text(msg, style: const TextStyle(fontSize: 13)),
          ],
          if (result.isNotEmpty) ...[
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cs.surfaceContainerLow,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: cs.outlineVariant),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final b in blocks)
                    Padding(
                      padding: EdgeInsets.only(top: b.kind == 'h' ? 14 : 0, bottom: 6),
                      child: b.kind == 'li'
                          ? Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Padding(
                                  padding: EdgeInsets.only(top: 10, left: 8),
                                  child: Icon(Icons.square, size: 7, color: Color(0xFFE0B400)),
                                ),
                                Expanded(child: SelectableText(b.text, style: const TextStyle(height: 1.9))),
                              ],
                            )
                          : SelectableText(
                              b.text,
                              style: b.kind == 'h'
                                  ? TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: cs.primary, height: 1.7)
                                  : const TextStyle(height: 1.9),
                            ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.icon(onPressed: _savePdf, icon: const Icon(Icons.picture_as_pdf), label: const Text('ذخیره PDF')),
              OutlinedButton.icon(
                  onPressed: () => _saveTxt(result, 'خلاصه'),
                  icon: const Icon(Icons.text_snippet_outlined),
                  label: const Text('ذخیره متن خلاصه')),
              if (widget.pages != null && fullText.isNotEmpty)
                OutlinedButton.icon(
                    onPressed: () => _saveTxt(fullText, 'متن کامل'),
                    icon: const Icon(Icons.notes),
                    label: const Text('ذخیره متن کامل کتاب')),
              OutlinedButton.icon(
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: result));
                  if (mounted) toast(context, 'کپی شد.');
                },
                icon: const Icon(Icons.copy),
                label: const Text('کپی'),
              ),
              OutlinedButton.icon(
                onPressed: () => Share.share(result),
                icon: const Icon(Icons.share),
                label: const Text('ارسال متن'),
              ),
            ]),
          ],
        ],
      ),
    );
  }
}

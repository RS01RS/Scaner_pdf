import 'dart:io';
import 'package:cunning_document_scanner/cunning_document_scanner.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../services/imaging.dart';
import '../services/ocr.dart';
import '../services/storage.dart';
import '../util.dart';
import 'summary_screen.dart';

/// اسکن متن: از عکس، متن را بیرون می‌آورد؛ قابل ویرایش، کپی، ذخیره و ارسال.
class TextScanScreen extends StatefulWidget {
  const TextScanScreen({super.key});

  @override
  State<TextScanScreen> createState() => _TextScanScreenState();
}

class _TextScanScreenState extends State<TextScanScreen> {
  final out = TextEditingController();
  final picker = ImagePicker();
  bool running = false;
  bool stop = false;
  String msg = '';
  double prog = 0;

  @override
  void dispose() {
    out.dispose();
    super.dispose();
  }

  Future<void> _fromPaths(List<String> paths) async {
    if (paths.isEmpty) return;
    setState(() {
      running = true;
      stop = false;
      out.clear();
      prog = 0;
    });
    final tmp = Store.tempDir('ocr_tmp');
    if (await tmp.exists()) await tmp.delete(recursive: true);
    final parts = <String>[];
    try {
      for (var i = 0; i < paths.length; i++) {
        if (stop) break;
        setState(() {
          msg = 'در حال خواندن صفحه‌ی ${fa(i + 1)} از ${fa(paths.length)}…';
          prog = i / paths.length;
        });
        // برای OCR رزولوشن بالاتر لازم است
        final it = await Imaging.importImage(paths[i], tmp, minSize: 2000, quality: 90);
        if (it == null) continue;
        final t = await Ocr.read(it);
        parts.add(paths.length > 1 ? '— صفحه‌ی ${fa(i + 1)} —\n$t' : t);
        out.text = parts.join('\n\n');
      }
      if (mounted) toast(context, parts.isEmpty ? 'متنی خوانده نشد.' : 'متن آماده است.');
    } catch (e) {
      if (mounted) toast(context, 'خواندن متن انجام نشد. عکس واضح‌تری بگیرید.');
    }
    try {
      await tmp.delete(recursive: true);
    } catch (_) {}
    if (mounted) setState(() => running = false);
  }

  Future<void> _camera() async {
    final x = await picker.pickImage(source: ImageSource.camera);
    if (x != null) await _fromPaths([x.path]);
  }

  Future<void> _scanner() async {
    try {
      final l = await CunningDocumentScanner.getPictures();
      if (l != null) await _fromPaths(l);
    } catch (_) {
      if (mounted) toast(context, 'اسکنر باز نشد. از دوربین یا گالری استفاده کنید.');
    }
  }

  Future<void> _gallery() async {
    final xs = await picker.pickMultiImage();
    await _fromPaths(xs.map((e) => e.path).toList());
  }

  Future<void> _saveTxt() async {
    final t = await chooseSaveTarget(context, defaultName: 'متن اسکن‌شده', ext: 'txt', defaultFolder: 'متن‌ها');
    if (t == null) return;
    await t.writeAsString(out.text);
    if (mounted) toast(context, 'ذخیره شد در ${Store.rel(t.parent.path)}');
  }

  Future<void> _shareFile() async {
    final f = File('${Store.tempPath}/متن-اسکن.txt');
    await f.writeAsString(out.text);
    await Share.shareXFiles([XFile(f.path)]);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final has = out.text.isNotEmpty;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('از کاغذ، کتاب یا صفحه‌ی نمایشگر عکس بگیرید تا متنش بیرون بیاید.',
            style: TextStyle(color: cs.onSurfaceVariant, height: 1.7)),
        const SizedBox(height: 12),
        Text('بدون اینترنت و رایگان کار می‌کند. دقت به وضوح عکس بستگی دارد؛ زبان تشخیص را از «تنظیمات» عوض کنید.',
            style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant, height: 1.7)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton.icon(onPressed: running ? null : _camera, icon: const Icon(Icons.photo_camera), label: const Text('دوربین')),
          OutlinedButton.icon(onPressed: running ? null : _scanner, icon: const Icon(Icons.document_scanner), label: const Text('اسکنر لبه‌یاب')),
          OutlinedButton.icon(onPressed: running ? null : _gallery, icon: const Icon(Icons.photo_library), label: const Text('گالری')),
        ]),
        if (running) ...[
          const SizedBox(height: 14),
          LinearProgressIndicator(value: prog <= 0 ? null : prog),
          const SizedBox(height: 6),
          Row(children: [
            Expanded(child: Text(msg, style: const TextStyle(fontSize: 13))),
            TextButton(onPressed: () => setState(() => stop = true), child: const Text('توقف')),
          ]),
        ],
        const SizedBox(height: 14),
        TextField(
          controller: out,
          minLines: 10,
          maxLines: null,
          textDirection: TextDirection.rtl,
          onChanged: (_) => setState(() {}),
          style: const TextStyle(height: 1.9),
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'متن استخراج‌شده اینجا نمایش داده می‌شود و می‌توانید ویرایشش کنید.',
          ),
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          OutlinedButton.icon(
            onPressed: has
                ? () async {
                    await Clipboard.setData(ClipboardData(text: out.text));
                    if (mounted) toast(context, 'متن کپی شد.');
                  }
                : null,
            icon: const Icon(Icons.copy),
            label: const Text('کپی'),
          ),
          OutlinedButton.icon(
            onPressed: has ? () => Share.share(out.text) : null,
            icon: const Icon(Icons.send),
            label: const Text('ارسال متن'),
          ),
          OutlinedButton.icon(onPressed: has ? _shareFile : null, icon: const Icon(Icons.attach_file), label: const Text('ارسال فایل')),
          OutlinedButton.icon(onPressed: has ? _saveTxt : null, icon: const Icon(Icons.save_alt), label: const Text('ذخیره در پوشه')),
          OutlinedButton.icon(
            onPressed: has
                ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SummaryScreen(text: out.text)))
                : null,
            icon: const Icon(Icons.auto_awesome),
            label: const Text('خلاصه کن'),
          ),
        ]),
      ],
    );
  }
}

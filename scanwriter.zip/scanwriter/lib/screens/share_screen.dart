import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services/storage.dart';
import '../util.dart';
import 'viewers.dart';

/// اشتراک‌گذاری اسناد، تصاویر، PDF و خلاصه‌ها.
/// منوی اشتراک اندروید باز می‌شود و هر برنامه‌ای که نصب است (تلگرام، بله، روبیکا، اینستاگرام،
/// واتس‌اپ، ایمیل) و همچنین بلوتوث و اشتراک نزدیک/وای‌فای (Quick Share) را نشان می‌دهد.
class ShareScreen extends StatefulWidget {
  const ShareScreen({super.key});

  @override
  State<ShareScreen> createState() => _ShareScreenState();
}

class _ShareScreenState extends State<ShareScreen> {
  List<File> all = [];
  final Set<String> sel = {};
  String filter = 'all';
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await Store.allFiles();
    if (mounted) setState(() {
      all = l;
      loading = false;
    });
  }

  List<File> get shown => all.where((f) {
        final k = Store.kindOf(f.path);
        switch (filter) {
          case 'pdf':
            return k == 'pdf';
          case 'image':
            return k == 'image';
          case 'text':
            return k == 'text';
          case 'summary':
            return Store.rel(f.parent.path).startsWith('خلاصه‌ها');
        }
        return true;
      }).toList();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final list = shown;
    const chips = {
      'all': 'همه',
      'pdf': 'PDF',
      'image': 'تصویر',
      'text': 'متن',
      'summary': 'خلاصه‌ها',
    };
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Align(
            alignment: Alignment.centerRight,
            child: Text(
              'فایل‌ها را انتخاب کنید و «ارسال» را بزنید. در منوی باز‌شده تلگرام، بله، روبیکا، اینستاگرام، ایمیل، بلوتوث و اشتراک نزدیک (وای‌فای) را می‌بینید.',
              style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13.5, height: 1.7),
            ),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            for (final e in chips.entries)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: Text(e.value),
                  selected: filter == e.key,
                  onSelected: (_) => setState(() => filter = e.key),
                ),
              ),
          ]),
        ),
        Expanded(
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : list.isEmpty
                  ? Center(child: Text('فایلی در این دسته نیست.', style: TextStyle(color: cs.onSurfaceVariant)))
                  : ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final f = list[i];
                        final on = sel.contains(f.path);
                        final k = Store.kindOf(f.path);
                        return CheckboxListTile(
                          value: on,
                          onChanged: (v) => setState(() => v == true ? sel.add(f.path) : sel.remove(f.path)),
                          secondary: IconButton(
                            icon: Icon(k == 'pdf' ? Icons.picture_as_pdf : (k == 'image' ? Icons.image : Icons.text_snippet)),
                            onPressed: () => openStoredFile(context, f),
                          ),
                          title: Text(baseName(f.path), overflow: TextOverflow.ellipsis),
                          subtitle: Text('${Store.rel(f.parent.path)}  •  ${humanSize(f.lengthSync())}',
                              style: const TextStyle(fontSize: 12)),
                        );
                      },
                    ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: Row(children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: sel.isEmpty
                      ? null
                      : () => Share.shareXFiles(sel.map((p) => XFile(p)).toList()),
                  icon: const Icon(Icons.share),
                  label: Text(sel.isEmpty ? 'ارسال' : 'ارسال ${fa(sel.length)} فایل'),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.outlined(onPressed: _load, icon: const Icon(Icons.refresh), tooltip: 'بازخوانی'),
            ]),
          ),
        ),
      ],
    );
  }
}

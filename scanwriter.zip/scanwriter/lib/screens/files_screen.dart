import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services/storage.dart';
import '../util.dart';
import 'print_screen.dart';
import 'viewers.dart';

/// پوشه‌ها و اسناد: ساخت پوشه، باز کردن، تغییر نام، انتقال، حذف، اشتراک و چاپ.
class FilesScreen extends StatefulWidget {
  const FilesScreen({super.key});

  @override
  State<FilesScreen> createState() => _FilesScreenState();
}

class _FilesScreenState extends State<FilesScreen> {
  late Directory cur;
  List<FileSystemEntity> items = [];
  final Set<String> sel = {};

  @override
  void initState() {
    super.initState();
    cur = Store.root;
    _load();
  }

  Future<void> _load() async {
    final l = await cur.list(followLinks: false).where((e) => !e.path.endsWith('.gitkeep')).toList();
    l.sort((a, b) {
      final ad = a is Directory ? 0 : 1, bd = b is Directory ? 0 : 1;
      if (ad != bd) return ad.compareTo(bd);
      if (a is File && b is File) return b.lastModifiedSync().compareTo(a.lastModifiedSync());
      return baseName(a.path).compareTo(baseName(b.path));
    });
    if (mounted) setState(() => items = l);
  }

  Future<void> _newFolder() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('پوشه‌ی جدید'),
        content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(labelText: 'نام پوشه')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('بساز')),
        ],
      ),
    );
    final name = sanitize(c.text);
    if (ok != true || name.isEmpty) return;
    await Directory('${cur.path}/$name').create();
    _load();
  }

  Future<void> _rename(FileSystemEntity e) async {
    final isFile = e is File;
    var base = baseName(e.path);
    var ext = '';
    if (isFile && base.contains('.')) {
      ext = base.substring(base.lastIndexOf('.'));
      base = base.substring(0, base.lastIndexOf('.'));
    }
    final c = TextEditingController(text: base);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تغییر نام'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ذخیره')),
        ],
      ),
    );
    final name = sanitize(c.text);
    if (ok != true || name.isEmpty) return;
    await e.rename('${e.parent.path}/$name$ext');
    _load();
  }

  Future<void> _move(List<String> paths) async {
    final d = await pickFolder(context);
    if (d == null) return;
    for (final p in paths) {
      final name = baseName(p);
      final dest = '${d.path}/$name';
      if (dest == p) continue;
      if (await FileSystemEntity.isDirectory(p)) {
        if (d.path.startsWith(p)) continue; // انتقال پوشه به داخل خودش
        await Directory(p).rename(dest);
      } else {
        await File(p).rename(dest);
      }
    }
    sel.clear();
    _load();
  }

  Future<void> _delete(List<String> paths) async {
    final ok = await confirmDialog(context, 'حذف', '${fa(paths.length)} مورد برای همیشه حذف شود؟', ok: 'حذف');
    if (!ok) return;
    for (final p in paths) {
      if (await FileSystemEntity.isDirectory(p)) {
        await Directory(p).delete(recursive: true);
      } else {
        await File(p).delete();
      }
    }
    sel.clear();
    _load();
  }

  IconData _icon(FileSystemEntity e) {
    if (e is Directory) return Icons.folder;
    switch (Store.kindOf(e.path)) {
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'image':
        return Icons.image;
      case 'text':
        return Icons.text_snippet;
    }
    return Icons.insert_drive_file;
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final atRoot = cur.path == Store.root.path;
    final selecting = sel.isNotEmpty;
    return Column(
        children: [
          Container(
            color: cs.surfaceContainerHighest,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(children: [
              if (!atRoot)
                IconButton(
                  icon: const Icon(Icons.arrow_upward),
                  onPressed: () {
                    cur = cur.parent;
                    sel.clear();
                    _load();
                  },
                ),
              Expanded(
                child: Text(atRoot ? 'همه‌ی پوشه‌ها' : Store.rel(cur.path),
                    overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              if (selecting) ...[
                Text(fa(sel.length)),
                IconButton(icon: const Icon(Icons.share), onPressed: () {
                  final fs = sel.where((p) => FileSystemEntity.isFileSync(p)).map((p) => XFile(p)).toList();
                  if (fs.isNotEmpty) Share.shareXFiles(fs);
                }),
                IconButton(icon: const Icon(Icons.drive_file_move_outline), onPressed: () => _move(sel.toList())),
                IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(sel.toList())),
                IconButton(icon: const Icon(Icons.close), onPressed: () => setState(sel.clear)),
              ] else
                IconButton(icon: const Icon(Icons.create_new_folder_outlined), tooltip: 'پوشه‌ی جدید', onPressed: _newFolder),
            ]),
          ),
          Expanded(
            child: items.isEmpty
                ? Center(child: Text('این پوشه خالی است.', style: TextStyle(color: cs.onSurfaceVariant)))
                : ListView.separated(
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final e = items[i];
                      final on = sel.contains(e.path);
                      final isDir = e is Directory;
                      String sub = '';
                      if (e is File) {
                        sub = '${humanSize(e.lengthSync())}  •  ${e.lastModifiedSync().toString().substring(0, 16)}';
                      }
                      return ListTile(
                        selected: on,
                        leading: Icon(_icon(e), color: isDir ? const Color(0xFFE0B400) : cs.primary, size: 30),
                        title: Text(baseName(e.path), overflow: TextOverflow.ellipsis),
                        subtitle: sub.isEmpty ? null : Text(sub, style: const TextStyle(fontSize: 12)),
                        onTap: () {
                          if (selecting) {
                            setState(() => on ? sel.remove(e.path) : sel.add(e.path));
                          } else if (isDir) {
                            cur = e;
                            _load();
                          } else {
                            openStoredFile(context, e as File);
                          }
                        },
                        onLongPress: () => setState(() => sel.add(e.path)),
                        trailing: selecting
                            ? Icon(on ? Icons.check_box : Icons.check_box_outline_blank)
                            : PopupMenuButton<String>(
                                onSelected: (v) {
                                  if (v == 'share' && e is File) Share.shareXFiles([XFile(e.path)]);
                                  if (v == 'print' && e is File) printStoredFile(context, e);
                                  if (v == 'rename') _rename(e);
                                  if (v == 'move') _move([e.path]);
                                  if (v == 'delete') _delete([e.path]);
                                },
                                itemBuilder: (_) => [
                                  if (e is File) const PopupMenuItem(value: 'share', child: Text('اشتراک‌گذاری')),
                                  if (e is File && Store.kindOf(e.path) != 'other')
                                    const PopupMenuItem(value: 'print', child: Text('چاپ')),
                                  const PopupMenuItem(value: 'rename', child: Text('تغییر نام')),
                                  const PopupMenuItem(value: 'move', child: Text('انتقال به پوشه')),
                                  const PopupMenuItem(value: 'delete', child: Text('حذف')),
                                ],
                              ),
                      );
                    },
                  ),
          ),
        ],
    );
  }
}

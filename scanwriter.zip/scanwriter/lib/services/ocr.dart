import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'imaging.dart';
import 'settings.dart';

/// تشخیص متن کاملاً آفلاین با Tesseract (داده‌ی زبان داخل خود برنامه است).
class Ocr {
  static Future<String> read(PageItem page) async {
    final t = await FlutterTesseractOcr.extractText(
      page.path,
      language: AppSettings.ocrLang,
      args: {
        'psm': '3',
        'preserve_interword_spaces': '1',
      },
    );
    return t.trim();
  }
}

import 'package:shared_preferences/shared_preferences.dart';

class AppSettings {
  /// زبان تشخیص متن: fas+eng | fas | eng
  static String ocrLang = 'fas+eng';

  static const langs = {
    'fas+eng': 'فارسی و انگلیسی',
    'fas': 'فقط فارسی',
    'eng': 'فقط انگلیسی',
  };

  static Future<void> load() async {
    final sp = await SharedPreferences.getInstance();
    ocrLang = sp.getString('ocrLang') ?? ocrLang;
    if (!langs.containsKey(ocrLang)) ocrLang = 'fas+eng';
  }

  static Future<void> save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('ocrLang', ocrLang);
  }
}

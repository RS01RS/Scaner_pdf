import 'dart:math';
import 'package:flutter/foundation.dart';

/// خلاصه‌ساز آفلاین (استخراجی): مهم‌ترین جمله‌های هر بخش از کتاب را بر اساس بسامد واژه‌های معنادار انتخاب می‌کند.
/// جمله‌ها بازنویسی نمی‌شوند؛ همان‌طور که در متن هستند و به ترتیب اصلی می‌آیند.
/// خروجی با قالب «# تیتر» و «- مورد فهرست» است تا با رندر PDF سازگار باشد.
String summarizeEntry(Map<String, dynamic> a) => Summarizer.run(
      (a['pages'] as List).cast<String>(),
      a['length'] as String,
      pagesMode: a['pagesMode'] as bool,
    );

Future<String> summarizeOffline(List<String> pages, String length, {required bool pagesMode}) =>
    compute(summarizeEntry, {'pages': pages, 'length': length, 'pagesMode': pagesMode});

class _Sent {
  final String text;
  final int page;
  final int order;
  final Set<String> words;
  double score = 0;
  _Sent(this.text, this.page, this.order, this.words);
}

class Summarizer {
  static const _stop = <String>{
    'و', 'در', 'به', 'از', 'که', 'این', 'را', 'با', 'است', 'برای', 'آن', 'یک', 'هم', 'بر', 'تا', 'یا', 'نیز',
    'اما', 'اگر', 'هر', 'همه', 'دیگر', 'بود', 'شد', 'می‌شود', 'می‌کند', 'کرد', 'کنند', 'بین', 'پس', 'همین',
    'چون', 'چه', 'خود', 'ها', 'های', 'ای', 'من', 'تو', 'او', 'ما', 'شما', 'آنها', 'آن‌ها', 'ایشان', 'باید',
    'شده', 'شود', 'کرده', 'کنید', 'نیست', 'هست', 'بودند', 'خواهد', 'دارد', 'دارند', 'داشت', 'وی', 'هیچ',
    'بسیار', 'بیشتر', 'کمتر', 'همچنین', 'ولی', 'اینکه', 'آنکه', 'چنین', 'چنان', 'بدون', 'روی', 'زیر', 'حتی',
    'مانند', 'طور', 'می‌توان', 'می‌تواند', 'نمی‌شود', 'نمی‌کند', 'شدند', 'کردند', 'بعد', 'قبل', 'هنگام', 'وقتی',
    'زیرا', 'بنابراین', 'یعنی', 'البته', 'تنها', 'فقط', 'نیز', 'اینجا', 'آنجا', 'چیزی', 'کسی', 'هرگز',
    'the', 'of', 'and', 'to', 'in', 'a', 'is', 'for', 'on', 'that', 'with', 'as', 'by', 'it', 'this', 'are',
    'be', 'or', 'an', 'at', 'from', 'was', 'were', 'has', 'have', 'not',
  };

  static String _norm(String s) => s
      .replaceAll('ي', 'ی')
      .replaceAll('ك', 'ک')
      .replaceAll(RegExp('[\\u064B-\\u065F\\u0670\\u0640]'), '');

  static final _wordRe = RegExp(r'[\p{L}\p{N}‌]+', unicode: true);

  static Iterable<String> _words(String s) =>
      _wordRe.allMatches(s.toLowerCase()).map((m) => m.group(0)!.replaceAll(RegExp(r'^‌+|‌+$'), ''));

  static bool _isContent(String w) =>
      w.length >= 3 && !_stop.contains(w) && !RegExp(r'^[\p{N}]+$', unicode: true).hasMatch(w);

  static String _fa(int n) {
    const d = '۰۱۲۳۴۵۶۷۸۹';
    return n.toString().split('').map((c) => d[int.parse(c)]).join();
  }

  static List<String> _splitSentences(String raw) {
    var t = _norm(raw);
    // حذف نشانگر صفحه
    t = t.replaceAll(RegExp(r'^—.*—\s*$', multiLine: true), '');
    // خط‌های شکسته‌ی یک پاراگراف را به هم می‌چسباند
    t = t.replaceAll(RegExp(r'(?<!\n)\n(?!\n)'), ' ');
    final out = <String>[];
    for (final para in t.split(RegExp(r'\n{2,}'))) {
      for (var s in para.split(RegExp(r'(?<=[.!?؟؛])\s+'))) {
        s = s.replaceAll(RegExp(r'\s+'), ' ').trim();
        if (s.isNotEmpty) out.add(s);
      }
    }
    return out;
  }

  static bool _plausible(String s) {
    final wc = s.split(' ').length;
    if (wc < 6 || wc > 55) return false;
    final letters = RegExp(r'[\p{L}]', unicode: true).allMatches(s).length;
    return letters / s.length > 0.6; // جمله‌های پر از نشانه و خطای OCR حذف می‌شوند
  }

  static double _jaccard(Set<String> a, Set<String> b) {
    if (a.isEmpty || b.isEmpty) return 0;
    final inter = a.intersection(b).length;
    return inter / (a.length + b.length - inter);
  }

  static String run(List<String> pageTexts, String length, {required bool pagesMode}) {
    final budget = length == 'short' ? 12 : (length == 'long' ? 60 : 30);
    final sents = <_Sent>[];
    final freq = <String, int>{};
    var order = 0;
    for (var p = 0; p < pageTexts.length; p++) {
      for (final s in _splitSentences(pageTexts[p])) {
        if (!_plausible(s)) continue;
        final ws = _words(s).where(_isContent).toSet();
        if (ws.length < 4) continue;
        sents.add(_Sent(s, p, order++, ws));
        for (final w in _words(s).where(_isContent)) {
          freq[w] = (freq[w] ?? 0) + 1;
        }
      }
    }
    if (sents.isEmpty) return '';
    final maxF = freq.values.reduce(max).toDouble();
    for (final s in sents) {
      var sum = 0.0;
      for (final w in s.words) {
        sum += freq[w]! / maxF;
      }
      s.score = sum / pow(s.words.length, 0.7);
    }

    final totalPages = pageTexts.length;
    final cap = max(1, budget ~/ 3);
    final sections = max(1, min(cap, (totalPages / 15).ceil()));
    final perSection = max(1, budget ~/ sections);

    final out = StringBuffer();
    final kw = freq.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final keys = kw.where((e) => e.value >= 2).take(12).map((e) => e.key).toList();
    if (keys.isNotEmpty) {
      out.writeln('# واژه‌های کلیدی');
      out.writeln(keys.join('، '));
    }

    for (var i = 0; i < sections; i++) {
      final from = (i * totalPages / sections).floor();
      final to = ((i + 1) * totalPages / sections).floor(); // انحصاری
      final cand = sents.where((s) => s.page >= from && s.page < max(to, from + 1)).toList();
      if (cand.isEmpty) continue;
      cand.sort((a, b) => b.score.compareTo(a.score));
      final picked = <_Sent>[];
      for (final c in cand) {
        if (picked.length >= perSection) break;
        if (picked.any((p) => _jaccard(p.words, c.words) > 0.6)) continue;
        picked.add(c);
      }
      picked.sort((a, b) => a.order.compareTo(b.order));
      final label = !pagesMode
          ? (sections == 1 ? 'مهم‌ترین نکته‌ها' : 'بخش ${_fa(i + 1)}')
          : (totalPages == 1
              ? 'مهم‌ترین نکته‌ها'
              : 'صفحه‌های ${_fa(from + 1)} تا ${_fa(max(to, from + 1))}');
      out.writeln('# $label');
      for (final s in picked) {
        out.writeln('- ${s.text}');
      }
    }
    return out.toString().trim();
  }
}

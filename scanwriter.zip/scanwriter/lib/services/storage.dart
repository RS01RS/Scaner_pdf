import 'dart:io';
import 'package:path_provider/path_provider.dart';

/// پوشه‌ها و فایل‌های برنامه. همه‌چیز داخل ScanWriter در حافظه‌ی اختصاصی برنامه ذخیره می‌شود.
class Store {
  static late Directory root;
  static late String docsPath;
  static late String tempPath;

  static const defaultFolders = ['اسناد', 'PDF', 'متن‌ها', 'خلاصه‌ها', 'تصاویر'];

  static Future<void> init() async {
    final d = await getApplicationDocumentsDirectory();
    final t = await getTemporaryDirectory();
    docsPath = d.path;
    tempPath = t.path;
    root = Directory('${d.path}/ScanWriter');
    for (final f in defaultFolders) {
      await Directory('${root.path}/$f').create(recursive: true);
    }
  }

  /// پوشه‌ی نشست (صفحه‌های در حال کار) - ماندگار تا با بستن برنامه از بین نرود
  static Directory sessionDir(String name) => Directory('$docsPath/sessions/$name');

  static Directory tempDir(String name) => Directory('$tempPath/$name');

  static String rel(String path) {
    if (path == root.path) return '';
    if (path.startsWith('${root.path}/')) return path.substring(root.path.length + 1);
    return path;
  }

  /// همه‌ی پوشه‌ها (به‌صورت بازگشتی) به‌همراه پوشه‌ی اصلی
  static Future<List<Directory>> allFolders() async {
    final out = <Directory>[];
    await for (final e in root.list(recursive: true, followLinks: false)) {
      if (e is Directory) out.add(e);
    }
    out.sort((a, b) => rel(a.path).compareTo(rel(b.path)));
    return out;
  }

  static Future<List<File>> allFiles() async {
    final out = <File>[];
    await for (final e in root.list(recursive: true, followLinks: false)) {
      if (e is File && !e.path.endsWith('.gitkeep')) out.add(e);
    }
    out.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    return out;
  }

  static Future<String> uniquePath(String dir, String base, String ext) async {
    var p = '$dir/$base.$ext';
    var i = 2;
    while (await File(p).exists()) {
      p = '$dir/$base ($i).$ext';
      i++;
    }
    return p;
  }

  static String kindOf(String path) {
    final e = path.toLowerCase().split('.').last;
    if (e == 'pdf') return 'pdf';
    if (['jpg', 'jpeg', 'png', 'webp'].contains(e)) return 'image';
    if (e == 'txt') return 'text';
    return 'other';
  }
}

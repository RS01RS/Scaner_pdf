import 'dart:convert';
import 'dart:io';
import 'imaging.dart';

/// نویسنده‌ی PDF که مستقیم روی فایل می‌نویسد، پس برای ۳۰۰ صفحه هم حافظه‌ی زیادی نمی‌گیرد.
/// هر صفحه یک عکس JPEG است (بدون بازرمزگذاری).
class PdfWriter {
  static Future<void> write(List<PageItem> pages, String outPath,
      {void Function(int done, int total)? onProgress}) async {
    final raf = await File(outPath).open(mode: FileMode.write);
    var off = 0;
    final offs = <int, int>{};

    Future<void> w(List<int> b) async {
      await raf.writeFrom(b);
      off += b.length;
    }

    Future<void> ws(String s) => w(latin1.encode(s));

    try {
      final n = pages.length;
      final total = 2 + 3 * n;
      await ws('%PDF-1.4\n');
      await w([0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A]);
      offs[1] = off;
      await ws('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
      final kids = [for (var i = 0; i < n; i++) '${3 + 3 * i} 0 R'].join(' ');
      offs[2] = off;
      await ws('2 0 obj\n<< /Type /Pages /Kids [$kids] /Count $n >>\nendobj\n');
      for (var k = 0; k < n; k++) {
        final it = pages[k];
        final p = 3 + 3 * k;
        final pw = 595;
        final ph = (595 * it.h / it.w).round().clamp(1, 20000);
        final bytes = await File(it.path).readAsBytes();
        offs[p] = off;
        await ws('$p 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $pw $ph] '
            '/Resources << /XObject << /Im0 ${p + 2} 0 R >> >> /Contents ${p + 1} 0 R >>\nendobj\n');
        final cs = 'q $pw 0 0 $ph 0 0 cm /Im0 Do Q';
        offs[p + 1] = off;
        await ws('${p + 1} 0 obj\n<< /Length ${cs.length} >>\nstream\n$cs\nendstream\nendobj\n');
        offs[p + 2] = off;
        await ws('${p + 2} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${it.w} /Height ${it.h} '
            '/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${bytes.length} >>\nstream\n');
        await w(bytes);
        await ws('\nendstream\nendobj\n');
        onProgress?.call(k + 1, n);
      }
      final xr = off;
      final sb = StringBuffer('xref\n0 ${total + 1}\n0000000000 65535 f \n');
      for (var q = 1; q <= total; q++) {
        sb.write('${offs[q]!.toString().padLeft(10, '0')} 00000 n \n');
      }
      sb.write('trailer\n<< /Size ${total + 1} /Root 1 0 R >>\nstartxref\n$xr\n%%EOF');
      await ws(sb.toString());
    } finally {
      await raf.close();
    }
  }
}

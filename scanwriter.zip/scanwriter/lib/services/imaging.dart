import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';

/// یک صفحه (فایل JPEG) با ابعاد
class PageItem {
  final String path;
  final int w;
  final int h;

  /// عکس اصلی قبل از فیلتر (برای برگرداندن به حالت اولیه)
  final String? orig;
  PageItem(this.path, this.w, this.h, {this.orig});

  Map<String, dynamic> toJson() => {'p': path, 'w': w, 'h': h, 'o': orig};
  factory PageItem.fromJson(dynamic m) =>
      PageItem(m['p'] as String, m['w'] as int, m['h'] as int, orig: m['o'] as String?);
}

/// پردازش پیکسلی فیلتر سند (در isolate جدا اجرا می‌شود).
/// ۱) روشنایی زمینه‌ی کاغذ با بیشینه‌ی بلوکی و هموارسازی برآورد می‌شود.
/// ۲) هر پیکسل بر زمینه تقسیم می‌شود تا سایه و نور ناهموار از بین برود.
/// ۳) منحنی سطوح، زمینه را سفید و نوشته را پررنگ می‌کند.
Uint8List filterPixels(Map<String, dynamic> a) {
  final px = a['px'] as Uint8List;
  final w = a['w'] as int;
  final h = a['h'] as int;
  final bw = (a['mode'] as String) == 'bw';
  final n = w * h;
  final lum = Uint8List(n);
  for (var i = 0, j = 0; i < n; i++, j += 4) {
    lum[i] = (px[j] * 77 + px[j + 1] * 150 + px[j + 2] * 29) >> 8;
  }
  final bs = math.max(12, w ~/ 50);
  final gw = (w + bs - 1) ~/ bs;
  final gh = (h + bs - 1) ~/ bs;
  var grid = List<double>.filled(gw * gh, 255);
  for (var by = 0; by < gh; by++) {
    for (var bx = 0; bx < gw; bx++) {
      var m = 0;
      final y1 = math.min(h, (by + 1) * bs), x1 = math.min(w, (bx + 1) * bs);
      for (var y = by * bs; y < y1; y++) {
        final row = y * w;
        for (var x = bx * bs; x < x1; x++) {
          final v = lum[row + x];
          if (v > m) m = v;
        }
      }
      grid[by * gw + bx] = math.max(60, m).toDouble();
    }
  }
  for (var pass = 0; pass < 2; pass++) {
    final g2 = List<double>.filled(gw * gh, 0);
    for (var y = 0; y < gh; y++) {
      for (var x = 0; x < gw; x++) {
        var s = 0.0;
        var c = 0;
        for (var dy = -1; dy <= 1; dy++) {
          for (var dx = -1; dx <= 1; dx++) {
            final yy = y + dy, xx = x + dx;
            if (yy < 0 || yy >= gh || xx < 0 || xx >= gw) continue;
            s += grid[yy * gw + xx];
            c++;
          }
        }
        g2[y * gw + x] = s / c;
      }
    }
    grid = g2;
  }
  final out = Uint8List(n * 4);
  final lo = bw ? 80.0 : 45.0, hi = bw ? 190.0 : 225.0;
  final k = 255.0 / (hi - lo);
  for (var y = 0; y < h; y++) {
    final fy = (((y + 0.5) / bs) - 0.5).clamp(0.0, gh - 1.0);
    final y0 = fy.floor(), y1 = math.min(y0 + 1, gh - 1);
    final ty = fy - y0;
    for (var x = 0; x < w; x++) {
      final fx = (((x + 0.5) / bs) - 0.5).clamp(0.0, gw - 1.0);
      final x0 = fx.floor(), x1 = math.min(x0 + 1, gw - 1);
      final tx = fx - x0;
      final top = grid[y0 * gw + x0] * (1 - tx) + grid[y0 * gw + x1] * tx;
      final bot = grid[y1 * gw + x0] * (1 - tx) + grid[y1 * gw + x1] * tx;
      final s = 255.0 / (top * (1 - ty) + bot * ty);
      final i = y * w + x;
      final j = i * 4;
      if (bw) {
        final v = ((lum[i] * s - lo) * k).clamp(0.0, 255.0).toInt();
        out[j] = v;
        out[j + 1] = v;
        out[j + 2] = v;
      } else {
        out[j] = ((px[j] * s - lo) * k).clamp(0.0, 255.0).toInt();
        out[j + 1] = ((px[j + 1] * s - lo) * k).clamp(0.0, 255.0).toInt();
        out[j + 2] = ((px[j + 2] * s - lo) * k).clamp(0.0, 255.0).toInt();
      }
      out[j + 3] = 255;
    }
  }
  return out;
}

class Block {
  final String kind; // h | p | li
  final String text;
  Block(this.kind, this.text);
}

class Imaging {
  static int _n = 0;
  // پلاگین فشرده‌سازی: تغییر اندازه فقط وقتی انجام می‌شود که ضلع کوتاه‌تر از این مقدار بزرگ‌تر باشد
  static const int noScale = 100000;

  static Future<PageItem?> importImage(String src, Directory dir,
      {int minSize = 1300, int quality = 82}) async {
    final bytes = await FlutterImageCompress.compressWithFile(
      src,
      minWidth: minSize,
      minHeight: minSize,
      quality: quality,
      format: CompressFormat.jpeg,
    );
    if (bytes == null) return null;
    return _save(bytes, dir);
  }

  static Future<PageItem> fromPng(Uint8List png, Directory dir, {int quality = 85}) async {
    final bytes = await FlutterImageCompress.compressWithList(
      png,
      minWidth: noScale,
      minHeight: noScale,
      quality: quality,
      format: CompressFormat.jpeg,
    );
    return _save(bytes, dir);
  }

  static Future<PageItem> _save(Uint8List bytes, Directory dir) async {
    await dir.create(recursive: true);
    final p = '${dir.path}/p_${DateTime.now().microsecondsSinceEpoch}_${_n++}.jpg';
    await File(p).writeAsBytes(bytes);
    final img = await decodeImageFromList(bytes);
    final item = PageItem(p, img.width, img.height);
    img.dispose();
    return item;
  }

  static Future<PageItem> rotate90(PageItem it, Directory dir) async {
    final bytes = await FlutterImageCompress.compressWithFile(
      it.path,
      minWidth: noScale,
      minHeight: noScale,
      quality: 90,
      rotate: 90,
      format: CompressFormat.jpeg,
    );
    if (bytes == null) return it;
    final out = await _save(bytes, dir);
    try {
      await File(it.path).delete();
    } catch (_) {}
    String? newOrig;
    if (it.orig != null) {
      final ob = await FlutterImageCompress.compressWithFile(
        it.orig!,
        minWidth: noScale,
        minHeight: noScale,
        quality: 90,
        rotate: 90,
        format: CompressFormat.jpeg,
      );
      if (ob != null) newOrig = (await _save(ob, dir)).path;
      try {
        await File(it.orig!).delete();
      } catch (_) {}
    }
    return PageItem(out.path, out.w, out.h, orig: newOrig);
  }

  /// فیلتر صفحه: none (برگرداندن اصل)، document (سند رنگی)، bw (سیاه‌وسفید).
  /// عکس اصلی نگه داشته می‌شود تا همیشه بشود فیلتر را عوض کرد یا برداشت.
  static Future<PageItem> applyFilter(PageItem it, String mode, Directory dir) async {
    final src = it.orig ?? it.path;
    if (mode == 'none') {
      if (it.orig == null) return it;
      try {
        await File(it.path).delete();
      } catch (_) {}
      return PageItem(src, it.w, it.h);
    }
    final bytes = await File(src).readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final img = frame.image;
    final w = img.width, h = img.height;
    final raw = await img.toByteData(format: ui.ImageByteFormat.rawRgba);
    img.dispose();
    final res = await compute(filterPixels, {
      'px': raw!.buffer.asUint8List(),
      'w': w,
      'h': h,
      'mode': mode,
    });
    final done = Completer<ui.Image>();
    ui.decodeImageFromPixels(res, w, h, ui.PixelFormat.rgba8888, done.complete);
    final outImg = await done.future;
    final png = await outImg.toByteData(format: ui.ImageByteFormat.png);
    outImg.dispose();
    final jpg = await FlutterImageCompress.compressWithList(
      png!.buffer.asUint8List(),
      minWidth: noScale,
      minHeight: noScale,
      quality: 88,
      format: CompressFormat.jpeg,
    );
    final saved = await _save(jpg, dir);
    if (it.orig != null) {
      try {
        await File(it.path).delete();
      } catch (_) {}
    }
    return PageItem(saved.path, saved.w, saved.h, orig: src);
  }

  /// نوشتن متن روی صفحه (yFrac: ۰ بالا، ۰٫۵ وسط، ۱ پایین)
  static Future<PageItem> stampText(PageItem it, String text, double yFrac, Directory dir) async {
    final bytes = await File(it.path).readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final img = frame.image;
    final rec = ui.PictureRecorder();
    final c = Canvas(rec);
    c.drawImage(img, Offset.zero, Paint());
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontFamily: 'Vazirmatn',
          fontSize: img.width / 16,
          fontWeight: FontWeight.w700,
          color: const Color(0xFFC62828),
          backgroundColor: const Color(0xB3FFFFFF),
        ),
      ),
      textDirection: TextDirection.rtl,
      textAlign: TextAlign.center,
    )..layout(maxWidth: img.width * 0.9);
    tp.paint(c, Offset((img.width - tp.width) / 2, (img.height - tp.height) * yFrac));
    final out = await rec.endRecording().toImage(img.width, img.height);
    final data = await out.toByteData(format: ui.ImageByteFormat.png);
    final w = img.width, h = img.height;
    img.dispose();
    out.dispose();
    final res = await FlutterImageCompress.compressWithList(
      data!.buffer.asUint8List(),
      minWidth: noScale,
      minHeight: noScale,
      quality: 90,
      format: CompressFormat.jpeg,
    );
    final item = await _save(res, dir);
    try {
      await File(it.path).delete();
    } catch (_) {}
    return PageItem(item.path, w, h);
  }

  // ---------- متن ساده به بلوک ----------
  static List<Block> parseBlocks(String t) {
    final out = <Block>[];
    for (var l in t.replaceAll('**', '').replaceAll('__', '').split(RegExp(r'\r?\n'))) {
      l = l.trim();
      if (l.isEmpty) continue;
      final h = RegExp(r'^#{1,4}\s+(.*)$').firstMatch(l);
      final li = RegExp(r'^[-•*]\s+(.*)$').firstMatch(l);
      if (h != null) {
        out.add(Block('h', h.group(1)!));
      } else if (li != null) {
        out.add(Block('li', li.group(1)!));
      } else {
        out.add(Block('p', l));
      }
    }
    return out;
  }

  // ---------- تبدیل متن فارسی به صفحه‌های A4 (تصویر) ----------
  // رسم با موتور متن فلاتر انجام می‌شود تا حروف فارسی درست به هم بچسبند.
  static Future<List<PageItem>> renderTextPages(
      String title, String subtitle, List<Block> blocks, Directory dir) async {
    const double W = 1240, H = 1754, M = 110;
    const double maxW = W - 2 * M;
    const double bottom = H - M - 40;
    final pages = <PageItem>[];
    late ui.PictureRecorder rec;
    late Canvas c;
    double y = M;
    int no = 0;

    void start() {
      rec = ui.PictureRecorder();
      c = Canvas(rec, const Rect.fromLTWH(0, 0, W, H));
      c.drawRect(const Rect.fromLTWH(0, 0, W, H), Paint()..color = Colors.white);
      y = M;
      no++;
    }

    TextPainter lay(String t, double size, Color col, {bool bold = false, double width = maxW}) {
      return TextPainter(
        text: TextSpan(
          text: t,
          style: TextStyle(
            fontFamily: 'Vazirmatn',
            fontSize: size,
            height: 1.9,
            color: col,
            fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
          ),
        ),
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.right,
      )..layout(minWidth: width, maxWidth: width);
    }

    Future<void> finish() async {
      final f = lay(fa2(no), 26, const Color(0xFF667788), width: maxW);
      f.paint(c, Offset(M, H - 80));
      final im = await rec.endRecording().toImage(W.toInt(), H.toInt());
      final bd = await im.toByteData(format: ui.ImageByteFormat.png);
      pages.add(await fromPng(bd!.buffer.asUint8List(), dir, quality: 88));
      im.dispose();
    }

    Future<void> put(String t, double size, Color col,
        {bool bold = false, double indent = 0, bool bullet = false, double gapAfter = 0}) async {
      final width = maxW - indent;
      var tp = lay(t, size, col, bold: bold, width: width);
      if (tp.height > bottom - M && t.contains(' ')) {
        // بلوک از یک صفحه بلندتر است؛ دو نیم می‌شود
        final words = t.split(' ');
        final mid = words.length ~/ 2;
        await put(words.sublist(0, mid).join(' '), size, col,
            bold: bold, indent: indent, bullet: bullet);
        await put(words.sublist(mid).join(' '), size, col, bold: bold, indent: indent);
        return;
      }
      if (y + tp.height > bottom && y > M + 1) {
        await finish();
        start();
        tp = lay(t, size, col, bold: bold, width: width);
      }
      tp.paint(c, Offset(M, y));
      if (bullet) {
        c.drawRect(Rect.fromLTWH(W - M - 12, y + tp.height / 2 - 7, 13, 13),
            Paint()..color = const Color(0xFFE0B400));
      }
      y += tp.height + gapAfter;
    }

    start();
    await put(title.isEmpty ? 'خلاصه‌ی کتاب' : title, 62, const Color(0xFF0E5A6B), bold: true, gapAfter: 4);
    await put(subtitle, 28, const Color(0xFF667788), gapAfter: 26);
    for (final b in blocks) {
      if (b.kind == 'h') {
        y += 22;
        await put(b.text, 42, const Color(0xFF0E5A6B), bold: true, gapAfter: 4);
      } else if (b.kind == 'li') {
        await put(b.text, 34, const Color(0xFF14202B), indent: 40, bullet: true, gapAfter: 8);
      } else {
        await put(b.text, 34, const Color(0xFF14202B), gapAfter: 14);
      }
    }
    await finish();
    return pages;
  }

  static String fa2(int n) {
    const d = '۰۱۲۳۴۵۶۷۸۹';
    return n.toString().split('').map((c) => d[int.parse(c)]).join();
  }
}

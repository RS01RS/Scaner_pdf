import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/files_screen.dart';
import 'screens/page_set.dart';
import 'screens/print_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/share_screen.dart';
import 'screens/text_scan.dart';
import 'services/settings.dart';
import 'services/storage.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.init();
  await AppSettings.load();
  runApp(const ScanWriterApp());
}

ThemeData _theme(Brightness b) {
  final cs = ColorScheme.fromSeed(seedColor: const Color(0xFF0E5A6B), brightness: b);
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    fontFamily: 'Vazirmatn',
    appBarTheme: const AppBarTheme(centerTitle: false),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(minimumSize: const Size(0, 46)),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 46)),
    ),
  );
}

class ScanWriterApp extends StatelessWidget {
  const ScanWriterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'اسکن‌نویس',
      debugShowCheckedModeBanner: false,
      locale: const Locale('fa', 'IR'),
      supportedLocales: const [Locale('fa', 'IR')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: const Shell(),
    );
  }
}

class Section {
  final String title;
  final IconData icon;
  final String blurb;
  final Widget Function() build;
  const Section(this.title, this.icon, this.blurb, this.build);
}

/// بخش‌ها به ترتیب منو. اندیس ۰ صفحه‌ی اصلی است.
final List<Section> sections = [
  Section('اسکن‌نویس', Icons.home_outlined, '', () => const SizedBox()),
  Section('اسکن متن', Icons.text_snippet_outlined, 'عکس بگیر، متن بگیر', () => const TextScanScreen()),
  Section('کتاب و تصویر به PDF', Icons.menu_book_outlined, 'کتاب ۲۰ تا ۳۰۰ صفحه‌ای', () => const PageSetScreen(mode: SetMode.book)),
  Section('خلاصه‌سازی جزوه و کتاب', Icons.auto_awesome_outlined, 'خلاصه‌ی آفلاین در PDF', () => const PageSetScreen(mode: SetMode.summary)),
  Section('اسکنر مدارک', Icons.document_scanner_outlined, 'کارت، شناسنامه، قبض', () => const PageSetScreen(mode: SetMode.scanner)),
  Section('ویرایشگر PDF', Icons.edit_document, 'حذف، جابه‌جایی، ادغام', () => const PageSetScreen(mode: SetMode.pdfEditor)),
  Section('پوشه‌ها و اسناد', Icons.folder_outlined, 'ذخیره و مرتب‌سازی', () => const FilesScreen()),
  Section('اشتراک‌گذاری', Icons.share_outlined, 'تلگرام، بله، روبیکا، بلوتوث', () => const ShareScreen()),
  Section('چاپ', Icons.print_outlined, 'اتصال به چاپگر', () => const PrintScreen()),
  Section('تنظیمات', Icons.settings_outlined, 'زبان تشخیص متن', () => const SettingsScreen()),
];

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final _key = GlobalKey<ScaffoldState>();
  int index = 0;
  final Map<int, Widget> _built = {};

  void go(int i) {
    setState(() => index = i);
    if (_key.currentState?.isEndDrawerOpen ?? false) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (index != 0) _built.putIfAbsent(index, () => sections[index].build());
    return PopScope(
      canPop: index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && index != 0) setState(() => index = 0);
      },
      child: Scaffold(
        key: _key,
        appBar: AppBar(
          title: Text(sections[index].title, style: const TextStyle(fontWeight: FontWeight.w700)),
          // منو سمت چپ بالا (در چیدمان راست‌به‌چپ، «actions» سمت چپ می‌ماند)
          actions: [
            IconButton(
              icon: const Icon(Icons.menu),
              tooltip: 'منو',
              onPressed: () => _key.currentState?.openEndDrawer(),
            ),
          ],
        ),
        endDrawer: Drawer(
          child: SafeArea(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                Container(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
                  color: cs.primaryContainer,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('اسکن‌نویس',
                          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: cs.onPrimaryContainer)),
                      const SizedBox(height: 4),
                      Text('اسکن، PDF، خلاصه، چاپ و اشتراک',
                          style: TextStyle(color: cs.onPrimaryContainer.withOpacity(.8), fontSize: 13)),
                    ],
                  ),
                ),
                for (var i = 0; i < sections.length; i++)
                  ListTile(
                    leading: Icon(sections[i].icon),
                    title: Text(i == 0 ? 'صفحه‌ی اصلی' : sections[i].title),
                    selected: index == i,
                    onTap: () => go(i),
                  ),
              ],
            ),
          ),
        ),
        body: IndexedStack(
          index: index,
          children: [
            _Home(onOpen: go),
            for (var i = 1; i < sections.length; i++) _built[i] ?? const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }
}

class _Home extends StatelessWidget {
  final void Function(int) onOpen;
  const _Home({required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('چه کاری انجام دهیم؟',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: cs.onSurface)),
        const SizedBox(height: 14),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.25,
          children: [
            for (var i = 1; i < sections.length; i++)
              InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => onOpen(i),
                child: Ink(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: cs.surfaceContainerHigh,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Icon(sections[i].icon, size: 30, color: cs.primary),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(sections[i].title,
                              maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
                          const SizedBox(height: 2),
                          Text(sections[i].blurb,
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
